<?php

namespace App\Http\Controllers;

//storage of the image 
use Illuminate\Support\Facades\Storage;

use Illuminate\Http\Request;

//Using Model name Movie and Actor
use App\Movie; 
use App\Actor; 

class MovieController extends Controller
{
    /*This function is to auth the user not to access pages 
    without login of user 
    **if the guest entires the page of manipulation he cannot access it 
    */
    public function __construct()
    {
        $this->middleware('auth',['except' => ['index']]);  
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {   
            
        $values = Movie::all();
        return view('movie.home')->with('values', $values);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $actor = Actor::all();

        return view('movie.create')->with('actor', $actor);

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        
       //validation of the values

       $this->validate($request,[
           'name'=>'required',
           'year' => 'required',
           'plot' => 'required ',
           'poster' => ' nullable',
           'actor' => 'required',
          
           
       ]);

       //Handling File 
       if($request->hasFile('poster'))
       {    
           //getting the whole file  with extension
            $File= $request->file('poster')->getClientOriginalName();

            //get filename
            $filename = pathinfo($File, PATHINFO_FILENAME);

            //get Extension of the file
            $ext = $request->file('poster')->getClientOriginalExtension();

            $FileNameToStore = $filename. '_'.time().'.'.$ext;
            //upload the image in a file 
            $path = $request->file('poster')->storeAs('public/Posters', $FileNameToStore);
       }
       else
       {
           //this name will be store in the database if no image 
           $FileNameToStore = 'noimage.png';
       }

       //Storing the values specified by the user

        $movie = new Movie;

        $movie->name =$request->input('name');
        $movie->year_of_release =$request->input('year');
        $movie->plot =$request->input('plot');
       $movie->cover_image = $FileNameToStore;
       $actor= '';
        foreach($request->input('actor')as $act)
       {
            $actor.= $act.',';
       }
       $actor =substr_replace($actor, '' ,-1);
       $movie->actors = $actor;
       


      $movie->save();
         
       return redirect('/movie')->with('success','Movie Added');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
       
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $actor = Actor::all();
        
        $edits = Movie::find($id);
        //the compact is used to send two variables in the view
        return view ('movie.edit',compact(['edits','actor']));
     

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $value  = Movie::find($id);
       //validation of the values

       $this->validate($request,[
        'name'=>'required',
        'year' => 'required',
        'plot' => 'required ',
        'poster' => ' nullable',
        'actor' => 'required',
       
        
    ]);
     
    //Handling File 
    if($request->hasFile('poster'))
    {    
        //getting the whole file  with extension
         $File= $request->file('poster')->getClientOriginalName();

         //get filename
         $filename = pathinfo($File, PATHINFO_FILENAME);

         //get Extension of the file
         $ext = $request->file('poster')->getClientOriginalExtension();

         $FileNameToStore = $filename. '_'.time().'.'.$ext;
         //upload the image in a file 
         $path = $request->file('poster')->storeAs('public/Posters/', $FileNameToStore);
    }
   

    //Storing the values specified by the user

     $movie = Movie::find($id);

     $movie->name = $request->input('name');
     $movie->year_of_release = $request->input('year');
     $movie->plot = $request->input('plot');
     if($request->input('poster')== ' ' )
     {
        $movie->cover_image = $value->cover_image;
     }
     $actor= '';
     foreach($request->input('actor')as $act)
       {
            $actor.= $act.',';
       }
       $actor =substr_replace($actor, '' ,-1);
       $movie->actors = $actor;
       

     $movie->save();
     return redirect('/movie')->with('successs','Movie Updated'); 


    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $dest= Movie::find($id);
      
       
        
        if($dest->cover_image != 'noimage.png')
        {
            //delete image
            Storage::delete('public/Posters/'.$dest->cover_image);
        }
        $dest->delete();
        return redirect('/movie')->with('successs','Movie Deleted'); 
    }
}
