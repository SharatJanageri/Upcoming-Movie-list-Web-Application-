<?php $__env->startSection('content'); ?>
    
<?php echo $__env->make('msg.err_msg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container">

    <?php echo e(Form::open(['action' => 'MovieController@store','id' => 'movieform', 'method' => 'POST', 'enctype'=>'multipart/form-data'])); ?>

    <div class ="form-group">
            <?php echo e(Form::label ('Name','Name')); ?>

            <?php echo e(Form::text('name', '',['class'=>'form-control col-md-5', 'placeholder'=> 'NAME OF THE MOVIE'])); ?>

    </div>
    <div class ="form-group">
            <?php echo e(Form::label ('Year of Release')); ?>

            <?php echo e(Form::date('year', '',['class'=>'form-control col-md-5', 'placeholder'=> 'YEAR OF THE MOVIE RELEASE'])); ?>

    </div>

    <div class ="form-group">
        <?php echo e(Form::label('Poster')); ?><br>
        <?php echo e(Form::file('poster')); ?>

    </div>

    <div class ="form-group">
        <?php echo e(Form::label ('Plot of the Movie')); ?>

        <?php echo e(Form::textarea('plot', '',['class'=>'form-control col-md-5', 'placeholder'=> 'PLOT OF THE MOVIE'])); ?>

    </div>
    <div class="form-group">
        <?php echo e(Form::label ('Actors')); ?>

        <!-- Actor adding -->
        <a href="/actor/create">
        <?php echo e(Form::button('+ Actors ',['class' => 'btn-sm btn-warning','id' => 'add_actor'])); ?>

        </a>
        <div id="act_load">

        </div>
        <select multiple class='form-control col-md-5' name="actor[]">
            <?php $__currentLoopData = $actor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value=<?php echo e($value->name); ?> ><?php echo e($value->name); ?></option>
                        
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
        </select>
    </div>

   <div class="form-group">
            
        </div>
        <div class="form-group">
      
        <?php echo e(Form::submit('Submit',['class'=>'btn btn-primary '])); ?>

        <?php echo e(Form::reset('Reset Values',['class'=> 'btn btn-default' ,'id' => 'reset'])); ?>

            <a href="/movie"><?php echo e(Form::button('Cancel',['class'=>'btn btn-danger'])); ?></a>
        </div>
  

<?php echo e(Form::close()); ?>


<script type="text/javascript">
    $("#add_actor").click(function(){
       load("/actor/create");
    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sharat/Desktop/laravel/movies/resources/views/movie/create.blade.php ENDPATH**/ ?>