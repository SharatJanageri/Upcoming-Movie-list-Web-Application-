@extends('layouts.app')

@section('content')

@include('msg.err_msg')
    <h1> Movies of 2018  
        
        <a href="/movie/create" >
        {{Form::button('+ Movie',['class'=> 'btn btn-default  pull-right'])}}
        </a>
    </h1>  <br>  
    <div class="col-sm-12">
    <table class="table">
        <thead class="thead-dark">
            <th> Poster</th>
            <th>Moive Name</th>
            <th >Year of Release(YYYY-MM-DD)</th>
            <th >Plot</th>
            <th >Cast</th>
            <th >Edit</th>
        </thead>

        @if(count($values)>0)
            @foreach ($values as $value)
            
                <tbody class="tbody">
                <td style="width:23%"  >
                <img style="width:200px; height: 190px " src="\storage\Posters\{{$value->cover_image}}"></td>
                <td>{{$value->name}} </td>
                <td>{{$value->year_of_release}}</td>
                <td>{{$value->plot}}</td>
                <td>{{$value->actors}}</td>
                <td> 
                <a href="/movie/{{$value->id}}/edit">
                    {{Form::button('Edit',['class'=>'btn btn-primary']) }}
                </a>
                {{Form::open(['action' => ['MovieController@destroy', $value->id],'method' => 'POST'])}}
                    {{Form::hidden('_method', 'DELETE')}}
                {{Form::submit('Delete',['class'=>'btn btn-danger']) }}
                {{Form::close()}}
                </td>
                 
                </tbody>
            </div>
         
            @endforeach
      
        </table>
       @endif

       
        
  
@endsection