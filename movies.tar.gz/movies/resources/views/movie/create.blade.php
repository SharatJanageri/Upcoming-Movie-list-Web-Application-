@extends('layouts.app')
@section('content')
    
@include('msg.err_msg')

<div class="container">

    {{ Form::open(['action' => 'MovieController@store','id' => 'movieform', 'method' => 'POST', 'enctype'=>'multipart/form-data']) }}
    <div class ="form-group">
            {{Form::label ('Name','Name')}}
            {{Form::text('name', '',['class'=>'form-control col-md-5', 'placeholder'=> 'NAME OF THE MOVIE'])}}
    </div>
    <div class ="form-group">
            {{Form::label ('Year of Release')}}
            {{Form::date('year', '',['class'=>'form-control col-md-5', 'placeholder'=> 'YEAR OF THE MOVIE RELEASE'])}}
    </div>

    <div class ="form-group">
        {{Form::label('Poster')}}<br>
        {{Form::file('poster')}}
    </div>

    <div class ="form-group">
        {{Form::label ('Plot of the Movie')}}
        {{Form::textarea('plot', '',['class'=>'form-control col-md-5', 'placeholder'=> 'PLOT OF THE MOVIE'])}}
    </div>
    <div class="form-group">
        {{Form::label ('Actors')}}
        <!-- Actor adding -->
        <a href="/actor/create">
        {{Form::button('+ Actors ',['class' => 'btn-sm btn-warning','id' => 'add_actor'])}}
        </a>
        <div id="act_load">

        </div>
        <select multiple class='form-control col-md-5' name="actor[]">
            @foreach ($actor as $value)
                <option value={{$value->name}} >{{$value->name}}</option>
                        
            @endforeach
                        
        </select>
    </div>

   <div class="form-group">
            
        </div>
        <div class="form-group">
      
        {{Form::submit('Submit',['class'=>'btn btn-primary '])}}
        {{Form::reset('Reset Values',['class'=> 'btn btn-default' ,'id' => 'reset'])}}
            <a href="/movie">{{Form::button('Cancel',['class'=>'btn btn-danger'])}}</a>
        </div>
  

{{ Form::close() }}

<script type="text/javascript">
    $("#add_actor").click(function(){
       load("/actor/create");
    });
</script>

@endsection