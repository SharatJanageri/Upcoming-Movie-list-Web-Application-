@extends('layouts.app')

@section('content')
@include('msg.err_msg')
<h1>Add Actor</h1>
<div class="container">
 
    @csrf
    <form id="actorform" method="post" onsubmit="fun()">
    <!--{{ Form::open(['method' => 'POST','id' => 'actorform','onsubmit'=>'fun()']) }} -->
    <div class ="form-group">
            {{Form::label ('Name','Name')}}
            {{Form::text('name', '',['class'=>'form-control col-md-5', 'placeholder'=> 'NAME OF ACTOR'])}}
    </div>
    <div class ="form-group">
         {{Form::label('Sex:')}}<br>
            Male{{Form::radio('sex', 'male')}}
            Female{{Form::radio('sex', 'female')}}
    </div>

   
    <div class ="form-group">
       {{Form::label('Date of Birth')}}
       {{Form::date('dob','',['class'=>'form-control col-md-5', 'placeholder'=> 'DATE OF BIRTH'])}}
    </div>
  

        <div class="form-group">
            {{Form::label('Bio')}}
            {{Form::textarea('bio','',['class'=>'form-control col-md-5', 'placeholder'=> 'BIO OF THE ACTOR'])}}
        </div>
        <div class="form-group">
           
      
        {{Form::submit('Submit',['class'=>'btn btn-primary '])}}
        {{Form::reset('Reset Values',['class'=> 'btn btn-default'])}}
       <a href="{{ URL::previous() }}">{{Form::button('Cancel',['class'=>'btn btn-danger'])}}</a>
        </div>
    <!--{{Form::close()}}-->
    </form>
</div>   
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js "> 
</script>
<script>
    function fun()
    {
    var name = document.getElementsByName('name').val();
    var sex = document.getElementsByName('sex').val();
    var dob = document.getElementsByName('dob').val();
    var bio = document.getElementsByName('bio').val();

    var data = new FormData();
    data.append('name',name);
    data.append('sex',sex);
    data.append('dob',dob);
    data.append('bio',bio);


            $.ajax({
                url: "{{route('store')}}",
                type: "POST",
                data: data,
                processData:false,
                contentType: false,
                cache:false,
               
                success:function(data)
                {
                    alert(data);

                }
               
                
            });
  
    }
   
</script>

@endsection
