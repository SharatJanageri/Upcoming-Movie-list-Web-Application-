@extends('layouts.app')

@section('content')

@include('msg.err_msg')
    <h1> Actors 
        
        <a href="/actor/create" >
        {{Form::button('+ Actor',['class'=> 'btn btn-default  pull-right'])}}
        </a>
    </h1>  
    <br>  
    <div class="col-sm-12">
    <table class="table">
        <thead class="thead-dark">
        
            <th>Name</th>
            <th >Sex</th>
            <th >Date of Birth(YYYY-MM-DD)</th>
            <th >Bio</th>
            <th >Edit</th>
        </thead>

        @if(count($actor)>0)
            @foreach ($actor as $value)
            
                <tbody class="tbody">
               
                <td>{{$value->name}} </td>
                <td>{{$value->sex}}</td>
                <td>{{$value->date_of_birth}}</td>
                <td>{{$value->bio}}</td>
                <td> 
                <a href="/actor/{{$value->id}}/edit">
                    {{Form::button('Edit',['class'=>'btn btn-primary']) }}
                </a>
              
                {{Form::close()}}
                {{Form::open(['action' => ['ActorController@destroy', $value->id],'method' => 'POST'])}}
                    {{Form::hidden('_method', 'DELETE')}}
                {{Form::submit('Delete',['class'=>'btn btn-danger']) }}
                {{Form::close()}}
                </td>
                 
                </tbody>
            </div>
         
            @endforeach
      
        </table>
       @endif

       
        
  
@endsection