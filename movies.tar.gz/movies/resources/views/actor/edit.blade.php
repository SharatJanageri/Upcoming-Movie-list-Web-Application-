@extends('layouts.app')


@section('content')
@include('msg.err_msg');

<h1>Edit Movie</h1>
<div class="container">

    {{ Form::open(['action' => ['ActorController@update', $edits->id], 'method' => 'PUT']) }}
    <div class ="form-group">
            {{Form::label ('Name','Name')}}
            {{Form::text('name', $edits->name,['class'=>'form-control col-md-5', 'placeholder'=> 'NAME OF THE MOVIE'])}}
    </div>
    <div class ="form-group">
            {{Form::label ('DOB')}}
            {{Form::date('dob', $edits->date_of_birth,['class'=>'form-control col-md-5', 'placeholder'=> 'YEAR OF THE MOVIE RELEASE'])}}
    </div>

    <div class ="form-group">
    
        {{Form::label ('Sex')}}
        {{Form::text('sex', $edits->sex,['class'=>'form-control col-md-5', 'placeholder'=> 'PLOT OF THE MOVIE'])}}
    </div>
    <div class ="form-group">
    
            {{Form::label ('Sex')}}
            {{Form::textarea('bio', $edits->bio,['class'=>'form-control col-md-5', 'placeholder'=> 'PLOT OF THE MOVIE'])}}
        </div>
    
  
    <div class="form-group">
        
        {{Form::hidden('__method','PUT')}}
        {{Form::submit('Submit',['class'=>'btn btn-primary '])}}
        {{Form::reset('Reset Values',['class'=> 'btn btn-default'])}}
       <a href="/actor">{{Form::button('Cancel',['class'=>'btn btn-danger'])}}</a>
    </div>
</div>    

{{ Form::close() }}
</div>

    
@endsection