<?php $__env->startSection('content'); ?>
<?php echo $__env->make('msg.err_msg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;

<h1>Edit Movie</h1>
<div class="container">

    <?php echo e(Form::open(['action' => ['MovieController@update', $edits->id], 'method' => 'PUT', 'enctype'=>'multipart/form-data'])); ?>

    <div class ="form-group">
            <?php echo e(Form::label ('Name','Name')); ?>

            <?php echo e(Form::text('name', $edits->name,['class'=>'form-control col-md-5', 'placeholder'=> 'NAME OF THE MOVIE'])); ?>

    </div>
    <div class ="form-group">
            <?php echo e(Form::label ('Year of Release')); ?>

            <?php echo e(Form::date('year', $edits->year_of_release,['class'=>'form-control col-md-5', 'placeholder'=> 'YEAR OF THE MOVIE RELEASE'])); ?>

    </div>

    <div class ="form-group">
            
        <?php echo e(Form::label('Poster')); ?><br>
        <img style="width:200px; height: 190px " src="/storage/Posters/<?php echo e($edits->cover_image); ?>"> 
    </div>
    <div class ="form-group">
        <?php echo e(Form::file('poster')); ?>

    </div>

    <div class ="form-group">
    
        <?php echo e(Form::label ('Plot of the Movie')); ?>

        <?php echo e(Form::textarea('plot', $edits->plot,['class'=>'form-control col-md-5', 'placeholder'=> 'PLOT OF THE MOVIE'])); ?>

    </div>

    <div class="form-group">
            <?php echo e(Form::label ('Actors')); ?>

            <!-- Actor adding -->
            <a href="/actor/create">
            <?php echo e(Form::button('+ Actors ',['class' => 'btn-sm btn-warning','id' => 'add_actor'])); ?>

            </a>
            
                    <select multiple class='form-control col-md-5' name="actor[]">
                    <?php $__currentLoopData = $actor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                        <option value=<?php echo e($value->name); ?> ><?php echo e($value->name); ?></option>
                      
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     
                    </select>
                  </div>
  
    <div class="form-group">
        
        <?php echo e(Form::hidden('__method','PUT')); ?>

        <?php echo e(Form::submit('Submit',['class'=>'btn btn-primary '])); ?>

        <?php echo e(Form::reset('Reset Values',['class'=> 'btn btn-default'])); ?>

       <a href="/movie"><?php echo e(Form::button('Cancel',['class'=>'btn btn-danger'])); ?></a>
    </div>
</div>    

<?php echo e(Form::close()); ?>

</div>

    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sharat/Desktop/laravel/movies/resources/views/movie/edit.blade.php ENDPATH**/ ?>