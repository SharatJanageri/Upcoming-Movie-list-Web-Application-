<?php $__env->startSection('content'); ?>
<?php echo $__env->make('msg.err_msg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;

<h1>Edit Movie</h1>
<div class="container">

    <?php echo e(Form::open(['action' => ['ActorController@update', $edits->id], 'method' => 'PUT'])); ?>

    <div class ="form-group">
            <?php echo e(Form::label ('Name','Name')); ?>

            <?php echo e(Form::text('name', $edits->name,['class'=>'form-control col-md-5', 'placeholder'=> 'NAME OF THE MOVIE'])); ?>

    </div>
    <div class ="form-group">
            <?php echo e(Form::label ('DOB')); ?>

            <?php echo e(Form::date('dob', $edits->date_of_birth,['class'=>'form-control col-md-5', 'placeholder'=> 'YEAR OF THE MOVIE RELEASE'])); ?>

    </div>

    <div class ="form-group">
    
        <?php echo e(Form::label ('Sex')); ?>

        <?php echo e(Form::text('sex', $edits->sex,['class'=>'form-control col-md-5', 'placeholder'=> 'PLOT OF THE MOVIE'])); ?>

    </div>
    <div class ="form-group">
    
            <?php echo e(Form::label ('Sex')); ?>

            <?php echo e(Form::textarea('bio', $edits->bio,['class'=>'form-control col-md-5', 'placeholder'=> 'PLOT OF THE MOVIE'])); ?>

        </div>
    
  
    <div class="form-group">
        
        <?php echo e(Form::hidden('__method','PUT')); ?>

        <?php echo e(Form::submit('Submit',['class'=>'btn btn-primary '])); ?>

        <?php echo e(Form::reset('Reset Values',['class'=> 'btn btn-default'])); ?>

       <a href="/actor"><?php echo e(Form::button('Cancel',['class'=>'btn btn-danger'])); ?></a>
    </div>
</div>    

<?php echo e(Form::close()); ?>

</div>

    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sharat/Desktop/laravel/movies/resources/views/actor/edit.blade.php ENDPATH**/ ?>