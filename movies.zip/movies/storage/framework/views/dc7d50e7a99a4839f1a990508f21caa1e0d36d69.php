<!DOCTYPE html>
<html>
<head>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
    
</head>
<body onclick="return()">
       

<div class="container">
   <div id="studentModal" class="modal" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="post" id="student_form">
                <div class="modal-header">
                    <a href="<?php echo e(URL::previous()); ?>">
                        <button type="button" class="close" >&times;</button>
                    </a>
                   <h4 class="modal-title">Add Data</h4>
                </div>
                <div class="modal-body">
                    <?php echo e(csrf_field()); ?>

                    <span id="form_output">

                    </span>

                    <div class="form-group">
                        <label> Name</label>
                        <input type="text" name="name" id="name" class="form-control" placeholder="Name of Actor" />
                    </div>
                    <div class="form-group">
                        <label>Sex</label>
                        <input type="text" name="sex" id="sex" class="form-control"placeholder="Male/Female" />
                    </div>
                    <div class="form-group">
                        <label>Date of Birth</label>
                        <input type="date" name="dob" id="dob" class="form-control" placeholder="Date of Birth of Actor"/>
                    </div>
                    <div class="form-group">
                        <label>Bio</label>
                        <textarea name="bio" id="bio" class="form-control" placeholder="Biography of Actor" >
                        </textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <input type="hidden" name="button_action" id="button_action" value="insert" />
                    <input type="submit" name="submit" id="action" value="Add" class="btn btn-info" />
                    <a href="<?php echo e(URL::previous()); ?>">
                        <button type="button" class="btn btn-default">Close</button>
                    </a>
                    </div>
            </form>
        </div>
    </div>
</div>
</div>


<script>
   


   $(document).ready(function()
   {
       $("#studentModal ").modal('show');
       $("#actor_form")[0].reset();
       $("#form_output").html('');
       $("button_action").val('insert');
       $("#action ").val('Add');
   });

    $('#student_form').on('submit', function(event)
    {
        event.preventDefault();
        var form_data = $(this).serialize();
        $.ajax({
            url:"<?php echo e(route('ajax.postdata')); ?>",
            type:"POST",
            data:form_data,
            dataType:"json",
            success:function(data)
            {
                $('#form_output').html(data.success); 
                $("#actor_form")[0].reset();
                $("#form_output").html('');
                $("button_action").val('insert');
                $("#action ").val('Add');

            }
                
        });
    });

    </script>

</body>
</html>

<?php /**PATH /home/sharat/Desktop/laravel/movies/resources/views/actor/create.blade.php ENDPATH**/ ?>