<?php $__env->startSection('content'); ?>

<?php echo $__env->make('msg.err_msg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <h1> Movies of 2018  
        
        <a href="/movie/create" >
        <?php echo e(Form::button('+ Movie',['class'=> 'btn btn-default  pull-right'])); ?>

        </a>
    </h1>  <br>  
    <div class="col-sm-12">
    <table class="table">
        <thead class="thead-dark">
            <th> Poster</th>
            <th>Moive Name</th>
            <th >Year of Release(YYYY-MM-DD)</th>
            <th >Plot</th>
            <th >Cast</th>
            <th >Edit</th>
        </thead>

        <?php if(count($values)>0): ?>
            <?php $__currentLoopData = $values; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
                <tbody class="tbody">
                <td style="width:23%"  >
                <img style="width:200px; height: 190px " src="\storage\Posters\<?php echo e($value->cover_image); ?>"></td>
                <td><?php echo e($value->name); ?> </td>
                <td><?php echo e($value->year_of_release); ?></td>
                <td><?php echo e($value->plot); ?></td>
                <td><?php echo e($value->actors); ?></td>
                <td> 
                <a href="/movie/<?php echo e($value->id); ?>/edit">
                    <?php echo e(Form::button('Edit',['class'=>'btn btn-primary'])); ?>

                </a>
                <?php echo e(Form::open(['action' => ['MovieController@destroy', $value->id],'method' => 'POST'])); ?>

                    <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                <?php echo e(Form::submit('Delete',['class'=>'btn btn-danger'])); ?>

                <?php echo e(Form::close()); ?>

                </td>
                 
                </tbody>
            </div>
         
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
        </table>
       <?php endif; ?>

       
        
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sharat/Desktop/laravel/movies/resources/views/movie/home.blade.php ENDPATH**/ ?>