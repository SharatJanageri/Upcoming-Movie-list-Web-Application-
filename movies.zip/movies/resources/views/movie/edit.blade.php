@extends('layouts.app')


@section('content')
@include('msg.err_msg');

<h1>Edit Movie</h1>
<div class="container">

    {{ Form::open(['action' => ['MovieController@update', $edits->id], 'method' => 'PUT', 'enctype'=>'multipart/form-data']) }}
    <div class ="form-group">
            {{Form::label ('Name','Name')}}
            {{Form::text('name', $edits->name,['class'=>'form-control col-md-5', 'placeholder'=> 'NAME OF THE MOVIE'])}}
    </div>
    <div class ="form-group">
            {{Form::label ('Year of Release')}}
            {{Form::date('year', $edits->year_of_release,['class'=>'form-control col-md-5', 'placeholder'=> 'YEAR OF THE MOVIE RELEASE'])}}
    </div>

    <div class ="form-group">
            
        {{Form::label('Poster')}}<br>
        <img style="width:200px; height: 190px " src="/storage/Posters/{{$edits->cover_image}}"> 
    </div>
    <div class ="form-group">
        {{Form::file('poster')}}
    </div>

    <div class ="form-group">
    
        {{Form::label ('Plot of the Movie')}}
        {{Form::textarea('plot', $edits->plot,['class'=>'form-control col-md-5', 'placeholder'=> 'PLOT OF THE MOVIE'])}}
    </div>

    <div class="form-group">
            {{Form::label ('Actors')}}
            <!-- Actor adding -->
            <a href="/actor/create">
            {{Form::button('+ Actors ',['class' => 'btn-sm btn-warning','id' => 'add_actor'])}}
            </a>
            
                    <select multiple class='form-control col-md-5' name="actor[]">
                    @foreach ($actor as $value)
                    
                        <option value={{$value->name}} >{{$value->name}}</option>
                      
                    @endforeach
                     
                    </select>
                  </div>
  
    <div class="form-group">
        
        {{Form::hidden('__method','PUT')}}
        {{Form::submit('Submit',['class'=>'btn btn-primary '])}}
        {{Form::reset('Reset Values',['class'=> 'btn btn-default'])}}
       <a href="/movie">{{Form::button('Cancel',['class'=>'btn btn-danger'])}}</a>
    </div>
</div>    

{{ Form::close() }}
</div>

    
@endsection