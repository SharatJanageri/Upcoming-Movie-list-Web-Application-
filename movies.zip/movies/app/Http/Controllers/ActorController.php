<?php

namespace App\Http\Controllers;
use DB;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Actor;
use App\Post;
use Config;
use Illuminate\Validation\Validator;//for validation of form 



class ActorController extends Controller
{
    /*This function is to auth the user not to access pages 
    without login of user 
    **if the guest entires the page of manipulation he cannot access it 
    */
    public function __construct()
    {
        $this->middleware('auth',['except' => 'index','store','create']);  
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
       $actor = Actor::all();
       return view('actor.index')->with('actor',$actor);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //actor/create page is redirect
        return view("actor.create");
        
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function save()
    {
        
    }
    public function store(Request $request)
    {
        $success ='';

        if($request->get('button_action') == "insert")
        {
            $actor =new Actor;
            $actor->name = $request->input('name');
            $actor->sex = $request->input('sex');
            $actor->date_of_birth = $request->input('dob');
            $actor->bio = $request->input('bio');
            
            $actor->save();
            $success ="<div class ='alert alert-sucesss'>Inserted Actor values</div>";
          
            
        }
        $out= array(
            'success' => $success
        );
        echo json_encode($out);
    
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $edits = Actor::find($id);
      
        return view('actor.edit')->with('edits',$edits);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $actor  = Actor::find($id);
        //validation of the values
 
        $this->validate($request,[
         'name'=>'required',
         'dob' => 'required',
         'sex' => 'required ',
         'bio' => 'required',
        
         
     ]);
     

     $actor->name = $request->input('name');
     $actor->date_of_birth= $request->input('dob');
     $actor->sex = $request->input('sex');
     $actor->bio = $request->input('bio');
       

     $actor->save();
     return redirect('/actor')->with('successs','Actor Updated'); 


    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $dele = Actor::find($id);
        $dele->destroy($id);
        return redirect('/actor')->with('successs','Actor Deleted'); 

    }
}
